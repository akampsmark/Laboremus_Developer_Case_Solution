﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevCaseFileProcessorLibrary.Entities
{
    public class FileDataRow
    {
        [Required(ErrorMessage = "Row is Missing an Region")]
        public string Region { get; set; }
        [Required(ErrorMessage = "Row is Missing an Country")]
        public string Country { get; set; }
        [Required(ErrorMessage = "Row is Missing an Item Type")]
        public string ItemType { get; set; }
        [Required(ErrorMessage = "Row is Missing an Sales Channel")]
        public string SalesChannel { get; set; }
        [Required(ErrorMessage = "Row is Missing an Order Priority")]
        public string OrderPriority { get; set; }
        [Required(ErrorMessage = "Row is Missing an Order Date")]
        public DateTime OrderDate { get; set; }
        [Required(ErrorMessage = "Row is Missing an OrderID")]
        public string OrderID { get; set; }
        [Required(ErrorMessage ="Row is Missing a Ship Date")]
        public DateTime ShipDate { get; set; }
        [Required(ErrorMessage = "Row is Missing an Units Sold")]
        [Range(0, double.MaxValue, ErrorMessage = "Units Sold Should Be Numeric > 0")]
        public string UnitsSold { get; set; }
        [Required(ErrorMessage = "Row is Missing an Unit Price")]
        [Range(0, double.MaxValue, ErrorMessage = "Unit Price Should Be Numeric > 0")]
        public string UnitPrice { get; set; }
        [Required(ErrorMessage = "Row is Missing an Unit Cost")]
        [Range(0, double.MaxValue, ErrorMessage = "Unit Cost Should Be Numeric")]
        public string UnitCost { get; set; }
        [Required(ErrorMessage = "Row is Missing an Total Revenue")]
        [Range(double.MinValue, double.MaxValue, ErrorMessage = "Total Revenue Should Be Numeric")]
        public string TotalRevenue { get; set; }
        [Required(ErrorMessage = "Row is Missing an Total Cost")]
        [Range(0, double.MaxValue, ErrorMessage = "Total Cost Should Be Numeric")]
        public string TotalCost { get; set; }
        [Required(ErrorMessage = "Row is Missing an Total Profit")]
        [Range(double.MinValue,double.MaxValue, ErrorMessage = "Total Profit Should Be Numeric")]
        public string TotalProfit { get; set; }
    }
}
