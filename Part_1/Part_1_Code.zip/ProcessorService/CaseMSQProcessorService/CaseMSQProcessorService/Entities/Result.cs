﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevCaseFileProcessorLibrary.Entities
{
    public class Result
    {
        public string DataBaseID = "";
        public string StatusCode = "";
        public string StatusDesc = "";
    }
}
