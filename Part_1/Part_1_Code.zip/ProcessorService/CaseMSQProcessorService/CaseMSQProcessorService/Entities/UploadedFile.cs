﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevCaseFileProcessorLibrary.Entities
{
    public class UploadedFile : Result
    {
        public string FilePath = "";
        public bool IsProcessed;
        public int TotalRecords;
        public string Failedrecords;
        public string SuccessfulRecords;
    }
}
