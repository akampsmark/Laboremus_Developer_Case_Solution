﻿using DevCaseFileProcessorLibrary.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DevCaseFileProcessorLibrary.Logic
{
    public class BusinessLogic
    {
        DataHandler dh = new DataHandler();
        private string[] SUCCESRECORDCOLUMNS = {
            "Region", "Country", "ItemType", "SalesChannel", "OrderPriority", "OrderDate", "OrderID", "ShipDate",
            "UnitsSold", "UnitPrice", "UnitCost", "TotalRevenue", "TotalCost", "TotalProfit", "SourceFileID"
            };
        private string[] FAILEDRECORDCOLUMNS = {"RowNumber", "FailureReason", "SourceFileID" };

        public DataTable GetUploadedFilesPendingProcessing()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = dh.ExecuteDataSet("GetUploadedFilesPendingProcessing", new string[] { }).Tables[0];
            }
            catch (Exception ex)
            {
                //Probably an sql error so logging is not okay, write error to file 
            }
            return dt;
        }

        public void ProcessUploadedFiles()
        {
            Result result = new Result();
            UploadedFile uploadedFile = new UploadedFile();
            try
            {
                DataTable dataTable = GetUploadedFilesPendingProcessing();
                Console.WriteLine("Picked "+ dataTable.Rows.Count+ " Files");
                foreach(DataRow dr in dataTable.Rows)
                {
                    try
                    {
                        uploadedFile = GetFileDetails(dr);
                        Console.WriteLine("Processing File " + uploadedFile.DataBaseID );
                        result = ProcessFile(uploadedFile, out uploadedFile.SuccessfulRecords, out uploadedFile.Failedrecords);
                        if (result.StatusCode.Equals("0"))
                        {
                            Console.WriteLine("File " + uploadedFile.DataBaseID+" Summary: SUCCESS: "+uploadedFile.SuccessfulRecords+" FAILED: "+uploadedFile.Failedrecords);
                            dh.ExecuteNonQuery("MarkFileAsProcessed",new string[] { uploadedFile.DataBaseID, uploadedFile.SuccessfulRecords, uploadedFile.Failedrecords });
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Processing File Error" + ex.Message);
                        // Log Error and Continue to others
                        dh.ExecuteNonQuery("LogError", new string[] { "ProcessorService", MethodBase.GetCurrentMethod().Name, ex.ToString() });
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private Result ValidatableObject(object objectTovalidate)
        {
            Result result = new Result();
            try
            {
                var context = new ValidationContext(objectTovalidate, null, null);
                List<ValidationResult> results = new List<ValidationResult>();
                bool Isvalid = Validator.TryValidateObject(objectTovalidate, context, results, true);
                if (Isvalid)
                {
                    result.StatusCode = "0";
                    result.StatusDesc = "SUCCESS";
                }
                else
                {
                    result.StatusCode = "100";
                    result.StatusDesc = results[0].ErrorMessage;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        private Result ProcessFile(UploadedFile uploadedFile, out string successfulRecords, out string failedrecords)
        {

            DataTable passedValidation = CreateDataTableUsingColumns(SUCCESRECORDCOLUMNS);
            DataTable failedValidation = CreateDataTableUsingColumns(FAILEDRECORDCOLUMNS);
            Result result = new Result();
            Result validationResult = new Result();
            string[] fileContents = File.ReadAllLines(uploadedFile.FilePath);
            int count = fileContents.Length;
            foreach(var row in fileContents.Select((Value, Index) => new { Value, Index }))
            {
                Console.WriteLine("Processing Record: " + row.Index + " of: " + count);
                try
                {
                    string[] rowData = row.Value.Split(new string[] { "," }, StringSplitOptions.None);
                    // Confirm All Columns are present
                    if (!rowData.Length.Equals(14))
                    {
                        DataRow failedRow = failedValidation.NewRow();
                        failedRow["RowNumber"] = row.Index + 1;
                        failedRow["FailureReason"] = "The Row is Missing some Columns";
                        failedRow["SourceFileID"] = uploadedFile.DataBaseID;
                        failedValidation.Rows.Add(failedRow);
                        continue;
                    }
                    
                    FileDataRow rowDetails = GetRowDetails(rowData);
                    // Validate the object
                    validationResult = ValidatableObject(rowDetails);
                    if (!validationResult.StatusCode.Equals("0"))
                    {
                        DataRow failedRow = failedValidation.NewRow();
                        failedRow["RowNumber"] = row.Index + 1;
                        failedRow["FailureReason"] = validationResult.StatusDesc;
                        failedRow["SourceFileID"] = uploadedFile.DataBaseID;
                        failedValidation.Rows.Add(failedRow);
                        continue;
                    }

                    // Eliminated Duplicate Check, Set Unique index to ignore duplicates on DB side
                    // Check For Duplicate OrderID
                    //if (passedValidation.AsEnumerable().Any(validrow => rowDetails.OrderID.Equals(validrow.Field<String>("OrderID"))))
                    //{
                    //    DataRow failedRow = failedValidation.NewRow();
                    //    failedRow["RowNumber"] = row.Index + 1;
                    //    failedRow["FailureReason"] = "The OrderId: " + rowDetails.OrderID + " is Duplicated";
                    //    failedRow["SourceFileID"] = uploadedFile.DataBaseID;
                    //    failedValidation.Rows.Add(failedRow);
                    //    continue;
                    //}

                    // At this point, this is a valid row for insertion
                    DataRow validRow = passedValidation.NewRow();
                    validRow["Region"] = rowDetails.Region;
                    validRow["Country"] = rowDetails.Country;
                    validRow["ItemType"] = rowDetails.ItemType;
                    validRow["SalesChannel"] = rowDetails.SalesChannel;
                    validRow["OrderPriority"] = rowDetails.OrderPriority;
                    validRow["OrderDate"] = rowDetails.OrderDate;
                    validRow["OrderID"] = rowDetails.OrderID;
                    validRow["ShipDate"] = rowDetails.ShipDate;
                    validRow["UnitsSold"] = rowDetails.UnitsSold;
                    validRow["UnitPrice"] = rowDetails.UnitPrice;
                    validRow["UnitCost"] = rowDetails.UnitCost;
                    validRow["TotalRevenue"] = rowDetails.TotalRevenue;
                    validRow["TotalCost"] = rowDetails.TotalCost;
                    validRow["TotalProfit"] = rowDetails.TotalProfit;
                    validRow["SourceFileID"] = uploadedFile.DataBaseID;
                    passedValidation.Rows.Add(validRow);
                }
                catch (Exception ex)
                {
                    DataRow failedRow = failedValidation.NewRow();
                    failedRow["RowNumber"] = row.Index + 1;
                    failedRow["FailureReason"] = ex.Message;
                    failedRow["SourceFileID"] = uploadedFile.DataBaseID;
                    failedValidation.Rows.Add(failedRow);
                    continue;
                }
                
            }

            result = dh.BulkInsertTransactions("BulkInsertSuccessfulData",dh.gl_connStringType,dh.gl_dbserver,passedValidation);
            if (!result.StatusCode.Equals("0"))
            {
                result.StatusDesc = result.StatusDesc + " ON INSERTING SUCCESSFUL RECORDS OF "+ uploadedFile.DataBaseID;
                successfulRecords = "0";
                failedrecords = "0";
                return result;
            }

            result = dh.BulkInsertTransactions("BulkInsertErrors", dh.gl_connStringType, dh.gl_dbserver, failedValidation);
            if (!result.StatusCode.Equals("0"))
            {
                result.StatusDesc = result.StatusDesc + " ON INSERTING FAILED RECORDS OF " + uploadedFile.DataBaseID;
                successfulRecords = "0";
                failedrecords = "0";
                return result;
            }

            failedrecords = failedValidation.Rows.Count.ToString();
            successfulRecords = passedValidation.Rows.Count.ToString();
            return result;
        }

        private FileDataRow GetRowDetails(string[] rowData)
        {
            FileDataRow rowDetails = new FileDataRow();
            rowDetails.Region = rowData[0];
            rowDetails.Country = rowData[1];
            rowDetails.ItemType = rowData[2];
            rowDetails.SalesChannel = rowData[3];
            rowDetails.OrderPriority = rowData[4];
            rowDetails.OrderDate = Convert.ToDateTime(rowData[5]);
            rowDetails.OrderID = rowData[6];
            rowDetails.ShipDate = Convert.ToDateTime(rowData[7]);
            rowDetails.UnitsSold = rowData[8];
            rowDetails.UnitPrice = rowData[9];
            rowDetails.UnitCost = rowData[10];
            rowDetails.TotalRevenue = rowData[11];
            rowDetails.TotalCost = rowData[12];
            rowDetails.TotalProfit = rowData[13];
            return rowDetails;
        }

        private UploadedFile GetFileDetails(DataRow dr)
        {
            UploadedFile uploadedFile = new UploadedFile();
            uploadedFile.DataBaseID = dr["RecordID"].ToString();
            uploadedFile.FilePath = dr["FilePath"].ToString();
            return uploadedFile;
        }

        internal DataTable CreateDataTableUsingColumns(string[] columns)
        {
            DataTable datTable = new DataTable();
            foreach(string column in columns)
            {
                datTable.Columns.Add(column);
            }
            return datTable;
        }
    }
}
