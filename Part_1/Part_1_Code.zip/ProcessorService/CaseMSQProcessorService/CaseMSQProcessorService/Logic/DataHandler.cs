﻿using DevCaseFileProcessorLibrary.Entities;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DevCaseFileProcessorLibrary.Logic
{
    public class DataHandler
    {
        public string ConnectionString = "ConnString";
        private Database Database;
        private DbCommand DBcommand;
        public string gl_dbserver = "";
        public string gl_catalog = "";
        public string gl_connStringType = "";

        public DataHandler()
        {
            try
            {
                Database = DatabaseFactory.CreateDatabase(ConnectionString);
                gl_dbserver = ReadAppSetting("DB_SERVER");
                gl_connStringType = ReadAppSetting("CONSTR_TYPE");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string ReadAppSetting(string key)
        {
            string result = "";
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                result = appSettings[key];

            }
            catch (ConfigurationErrorsException configEx)
            {
                ExecuteNonQuery("LogError", new string[] { "ProcessorService", MethodBase.GetCurrentMethod().Name, configEx.ToString() });
            }
            return result;
        }
        public Result BulkInsertTransactions(string StoredProcedure, string connStringType, string dbserver, DataTable dt)
        {
            Result result = new Result();
            try
            {
                int rows = 0;
                if (dt.Rows.Count > 0)
                {
                    string connectionString = ConfigurationManager.ConnectionStrings[connStringType].ConnectionString;
                    connectionString = String.Format(connectionString, dbserver);

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmdBulkInsert = new SqlCommand(StoredProcedure, connection)
                        {
                            CommandType = CommandType.StoredProcedure
                        };

                        SqlParameter tvpParam = cmdBulkInsert.Parameters.AddWithValue("@TableData", dt);
                        tvpParam.SqlDbType = SqlDbType.Structured;

                        connection.Open();
                        cmdBulkInsert.CommandTimeout = 0;
                        rows = cmdBulkInsert.ExecuteNonQuery();
                        connection.Close();
                    }
                    // No errors, SUCCESS
                    result.DataBaseID = "";
                    result.StatusCode = "0";
                    result.StatusDesc = "SUCCESS";
                }
                else
                {
                    // Empty DataTable, SUCCESS
                    result.DataBaseID = "";
                    result.StatusCode = "0";
                    result.StatusDesc = "SUCCESS";
                }
            }
            catch (Exception ex)
            {
                ExecuteNonQuery("LogError", new string[] { "ProcessorService", MethodBase.GetCurrentMethod().Name, ex.ToString() });
                result.DataBaseID = "";
                result.StatusCode = "100";
                result.StatusDesc = ex.Message.ToUpper();
            }

            return result;
        }

        internal Result ExecuteNonQuery(string storedProcedureName, string[] Parameters)
        {
            Result result = new Result();
            try
            {
                DBcommand = Database.GetStoredProcCommand(storedProcedureName, Parameters);
                int rows = Database.ExecuteNonQuery(DBcommand);
                result.DataBaseID = "" + rows;
                result.StatusCode = "0";
                result.StatusDesc = "SUCCESS";
            }
            catch (Exception ex)
            {
                result.DataBaseID = "";
                result.StatusCode = "100";
                result.StatusDesc = "FAILED: " + ex.Message.ToUpper();
            }
            return result;
        }

        internal DataSet ExecuteDataSet(string storedProcedureName, string[] Parameters)
        {
            try
            {
                DBcommand = Database.GetStoredProcCommand(storedProcedureName,
                                                           Parameters
                                                          );
                DataSet ds = Database.ExecuteDataSet(DBcommand);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

