﻿using DevCaseFileProcessorLibrary.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            BusinessLogic bll = new BusinessLogic();
            while (true)
            {
                bll.ProcessUploadedFiles();
            }
        }
    }
}
