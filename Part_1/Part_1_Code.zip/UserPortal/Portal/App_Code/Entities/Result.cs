﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Portal.App_Code.Entities
{
    public class Result
    {
        public string DataBaseID = "";
        public string StatusCode = "";
        public string StatusDesc = "";
    }
}