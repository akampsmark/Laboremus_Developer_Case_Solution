﻿using Portal.App_Code.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;

namespace Portal.App_Code.Logic
{
    public class BusinessLogic
    {
        DataHandler dh = new DataHandler();

        public void ShowMessage(Label lblmsg, string msg, bool IsError, System.Web.SessionState.HttpSessionState Session)
        {
            lblmsg.Text = msg;
            if (IsError)
            {
                Session["IsError"] = "True";
                lblmsg.ForeColor = System.Drawing.Color.Red; lblmsg.Font.Bold = true;
            }
            else
            {
                Session["IsError"] = "False";
                lblmsg.ForeColor = System.Drawing.Color.Black; lblmsg.Font.Bold = true;
            }
        }

        public Result LogFileInDB(string filePath, Int32 totalNumberOfrecords )
        {
            Result result = new Result();
            try
            {
                result = dh.ExecuteNonQuery("LogFileDetails", new string[] { filePath, totalNumberOfrecords.ToString() });
            }
            catch (Exception ex)
            {
                result.DataBaseID = "";
                result.StatusCode = "100";
                result.StatusDesc = ex.Message.ToUpper();
            }
            return result;
        }

        internal string CalculateTotal(DataTable dt, string columnName)
        {
            double sum = 0;
                foreach(DataRow drow in dt.Rows)
                {
                    try
                    {
                        sum = sum + Convert.ToDouble(drow[columnName].ToString());
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
            return sum.ToString("#,##0.00");
        }
    }
}