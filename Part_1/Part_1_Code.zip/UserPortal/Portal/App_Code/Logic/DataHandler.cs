﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Portal.App_Code.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace Portal.App_Code.Logic
{
    public class DataHandler
    {
        public string ConnectionString = "ConnString";
        private Database Database;
        private DbCommand DBcommand;

        public DataHandler()
        {
            try
            {
                Database = DatabaseFactory.CreateDatabase(ConnectionString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        internal Result ExecuteNonQuery(string storedProcedureName, string[] Parameters)
        {
            Result result = new Result();
            try
            {
                DBcommand = Database.GetStoredProcCommand(storedProcedureName,Parameters);
                int rows = Database.ExecuteNonQuery(DBcommand);
                result.DataBaseID = "" + rows;
                result.StatusCode = "0";
                result.StatusDesc = "SUCCESS";
            }
            catch (Exception ex)
            {
                result.DataBaseID = "";
                result.StatusCode = "100";
                result.StatusDesc = "FAILED: "+ex.Message.ToUpper();
            }
            return result;
        }

        internal DataSet ExecuteDataSet(string storedProcedureName, string[] Parameters)
        {
            try
            {
                DBcommand = Database.GetStoredProcCommand(storedProcedureName,
                                                           Parameters
                                                          );
                DataSet ds = Database.ExecuteDataSet(DBcommand);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}