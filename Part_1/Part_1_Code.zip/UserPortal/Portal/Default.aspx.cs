﻿using System;
using System.Net;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Portal.App_Code.Logic;
using Portal.App_Code.Entities;
using System.Reflection;

namespace Portal
{
    public partial class _Default : Page
    {
        BusinessLogic bll = new BusinessLogic();
        DataHandler dh = new DataHandler();
        private string BASEPATH = AppDomain.CurrentDomain.BaseDirectory;
        private string UPLOADFOLDER = @"Upload\";
        private string FILEPATH ="";
        Label lblmsg;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg = Master.FindControl("lblmsg") as Label;
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            Result result = new Result();
            //string filePath = ""; 
            try
            {
                if (FileUpload1.HasFile)
                {
                    // Confirm File is a CSV
                    if (!Path.GetExtension(FileUpload1.FileName).ToUpper().Equals(".CSV"))
                    {
                        bll.ShowMessage(lblmsg, "PLEASE UPLOAD A CSV INSTEAD OF "+ Path.GetExtension(FileUpload1.FileName).ToUpper()+" FILE", true, Session);
                        return;
                    }

                    FILEPATH = BASEPATH + UPLOADFOLDER;
                    // Check if the upload folder exists or create it
                    if (!Directory.Exists(FILEPATH))
                    {
                        Directory.CreateDirectory(FILEPATH);
                    }
                    // Set where to store files on disk
                    FILEPATH = FILEPATH + "Upload_" + "" + DateTime.Now.ToString("dd-mm-yyyy_HH-mm-ss") + "_" + FileUpload1.FileName;

                    FileUpload1.SaveAs(FILEPATH);
                    // Read the file to do basic column validations
                    string[] Content = File.ReadAllLines(FILEPATH);
                    string[] row = Content[0].Split(new string[] { "," }, StringSplitOptions.None);
                    if (!row.Length.Equals(14))
                    {
                        File.Delete(FILEPATH);
                        bll.ShowMessage(lblmsg, "WRONG FORMAT OF CSV UPLOADED. PLEASE CHOOSE CORRECT TO UPLOAD [ SHOULD HAVE 14 COLUMNS]", true, Session);
                        return;
                    }
                    result = bll.LogFileInDB(FILEPATH, Content.Length - 1);

                    // Log to the db for processing
                    if (result.StatusCode.Equals("0"))
                    {
                        bll.ShowMessage(lblmsg, "FILE LOGGED SUCCESSFULLY FOR PROCESSING.", false, Session);
                    }
                    else
                    {
                        File.Delete(FILEPATH);
                        bll.ShowMessage(lblmsg, result.StatusDesc, true, Session);
                    }
                }
                else
                {
                    bll.ShowMessage(lblmsg, "NO FILE SELECTED FOR UPLOAD. PLEASE CHOOSE FILE TO UPLOAD", true, Session);
                    return;
                }

            }
            catch (Exception ex)
            {
                dh.ExecuteNonQuery("LogError",new string[] { "Portal", MethodBase.GetCurrentMethod().Name, ex.ToString() });
                bll.ShowMessage(lblmsg, ex.Message.ToUpper(), true, Session);
            }
        }
    }
}