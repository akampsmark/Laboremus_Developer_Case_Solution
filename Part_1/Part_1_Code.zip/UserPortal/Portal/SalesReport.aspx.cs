﻿using Portal.App_Code.Logic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Portal
{
    public partial class SalesReport : System.Web.UI.Page
    {
        BusinessLogic bll = new BusinessLogic();
        Label lblmsg;
        DataHandler dh = new DataHandler();
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg = Master.FindControl("lblmsg") as Label;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string fromDate = txtFromDate.Text.Trim();
                string toDate = txtToDate.Text.Trim();
  
                DataTable dt = dh.ExecuteDataSet("SearchSalesTableForReport", new string[] { fromDate, toDate }).Tables[0];

                if (dt.Rows.Count > 0)
                {
                    string msg = "Total Revenue: " + bll.CalculateTotal(dt, "TotalRevenue") + " From "+ dt.Rows.Count+" Orders";
                    dataGridResults.DataSource = dt;
                    dataGridResults.DataBind();
                    Multiview2.ActiveViewIndex = 0;
                    bll.ShowMessage(lblmsg, msg, false, Session);
                }
                else
                {
                    dataGridResults.DataSource = null;
                    dataGridResults.DataBind();
                    Multiview2.ActiveViewIndex = -1;
                    string msg = "No Orders Found Matching Date Range Criteria";
                    bll.ShowMessage(lblmsg, msg, true, Session);
                }
            }
            catch (Exception ex)
            {
                dh.ExecuteNonQuery("LogError", new string[] { "Portal", MethodBase.GetCurrentMethod().Name, ex.ToString() });
                bll.ShowMessage(lblmsg, ex.Message.ToUpper(), true, Session);
            }
        }

        protected void dataGridResults_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            dataGridResults.PageIndex = e.NewPageIndex;
            btnSubmit_Click(sender, e);
        }
    }
}