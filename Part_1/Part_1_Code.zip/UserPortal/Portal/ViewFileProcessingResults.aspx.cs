﻿using Portal.App_Code.Logic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Portal
{
    public partial class ViewFileProcessingResults : System.Web.UI.Page
    {
        BusinessLogic bll = new BusinessLogic();
        Label lblmsg;
        DataHandler dh = new DataHandler();
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg = Master.FindControl("lblmsg") as Label;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            try
            {
                string fromDate = txtFromDate.Text.Trim();
                string toDate = txtToDate.Text.Trim();
                if (string.IsNullOrEmpty(fromDate))
                {
                    bll.ShowMessage(lblmsg, "PLEASE SELECT A START DATE", true, Session);
                    return;
                }
                if (string.IsNullOrEmpty(toDate))
                {
                    bll.ShowMessage(lblmsg, "PLEASE SELECT AN END DATE", true, Session);
                    return;
                }
                DataSet dsett = dh.ExecuteDataSet("SearchSalesTable", new string[] { fromDate, toDate });
                DataTable dt1 = dsett.Tables[0];
                DataTable dt2 = dsett.Tables[1];
                if (dt1.Rows.Count > 0)
                {
                    string msg = "Total Profit Made: " + bll.CalculateTotal(dt2, "TotalProfit") ;
                    dataGridResults.DataSource = dt1;
                    dataGridResults.DataBind();
                    Multiview2.ActiveViewIndex = 0;
                    bll.ShowMessage(lblmsg, msg, false, Session);
                }
                else
                {
                    dataGridResults.DataSource = null;
                    dataGridResults.DataBind();
                    Multiview2.ActiveViewIndex = -1;
                    string msg = "No Orders Found Matching Date Range Criteria";
                    bll.ShowMessage(lblmsg, msg, true, Session);
                }
            }
            catch (Exception ex)
            {
                dh.ExecuteNonQuery("LogError", new string[] { "Portal", MethodBase.GetCurrentMethod().Name, ex.ToString() });
                bll.ShowMessage(lblmsg, ex.Message.ToUpper(), true, Session);
            }
        }
    }
}